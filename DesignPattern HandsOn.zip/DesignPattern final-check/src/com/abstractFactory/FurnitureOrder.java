package com.abstractFactory;

public class FurnitureOrder extends Order {
	
	public void processOrder() {
		this.setChannel("Furniture channel");
		this.setProductType("Table");
		System.out.println("Furniture order is in process");
	}
}
