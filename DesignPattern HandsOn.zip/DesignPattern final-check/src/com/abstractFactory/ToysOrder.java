package com.abstractFactory;

public class ToysOrder extends Order {
	
	public void processOrder() {
		this.setChannel("Toys channel");
		this.setProductType("Ball");
		System.out.println("Toys order is in process");
	}
}
