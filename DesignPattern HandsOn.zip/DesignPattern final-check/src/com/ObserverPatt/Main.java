package com.ObserverPatt;

public class Main {

	public static void main(String[] args) {
		// create subject
		Admin topic = new Admin();

		// create observers
		Observer o1 = new NotificationSubscriber("ram");
		Observer o2 = new NotificationSubscriber("sam");
		Observer o3 = new NotificationSubscriber("dam");

		// register observers to the subject
		topic.register(o1);
		topic.register(o2);
		topic.register(o3);

		// attach observer to subject
		o1.setSubscriber(topic);
		o2.setSubscriber(topic);
		o3.setSubscriber(topic);

		// check if any update is available
		o1.update();

		// now send message to subject
		topic.postMessage("hello");

		topic.unregister(o3);

		topic.postMessage("lol");
	}

}
