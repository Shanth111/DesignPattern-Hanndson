public interface Musd {
    // returns speed in USD 
    double getCurr();
}
