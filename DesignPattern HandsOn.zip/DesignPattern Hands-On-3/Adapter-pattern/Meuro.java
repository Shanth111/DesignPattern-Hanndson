public interface Meuro {
	 // returns in euro 
    double getCurr();
}
