public class CurrUSD implements Musd {
	public double getCurr() {
		return 50;
	}
}

