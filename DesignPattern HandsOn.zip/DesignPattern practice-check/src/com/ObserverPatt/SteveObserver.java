package com.ObserverPatt;

public class SteveObserver implements INotificationObserver{
	
	String personName;

	public SteveObserver(String personName) {
		this.personName = personName;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public void OnServerDown() {
		
		System.out.println("Hello "+personName+", Notification has been received");
	}
}
