package com.ObserverPatt;

public interface INotificationObserver {
	  public void OnServerDown();
}
