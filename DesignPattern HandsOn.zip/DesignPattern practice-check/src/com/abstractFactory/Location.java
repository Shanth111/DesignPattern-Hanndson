package com.abstractFactory;

public enum Location {
	DEFAULT, USA, INDIA;
}
