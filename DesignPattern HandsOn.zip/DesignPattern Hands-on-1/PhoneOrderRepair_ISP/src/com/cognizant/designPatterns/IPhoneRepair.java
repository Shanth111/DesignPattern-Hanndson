package com.cognizant.designPatterns;

public interface IPhoneRepair extends IRepair{
	void ProcessPhoneRepair(String modelName);
}
