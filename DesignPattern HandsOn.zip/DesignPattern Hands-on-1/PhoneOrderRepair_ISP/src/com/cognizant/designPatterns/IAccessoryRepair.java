package com.cognizant.designPatterns;

public interface IAccessoryRepair extends IRepair{
	void ProcessAccessoryRepair(String accessoryName);
}
