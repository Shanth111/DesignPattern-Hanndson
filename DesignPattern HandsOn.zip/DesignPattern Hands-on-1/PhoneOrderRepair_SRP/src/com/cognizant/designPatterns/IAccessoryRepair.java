package com.cognizant.designPatterns;

public interface IAccessoryRepair {
	void ProcessAccessoryRepair(String accessoryType);
}
